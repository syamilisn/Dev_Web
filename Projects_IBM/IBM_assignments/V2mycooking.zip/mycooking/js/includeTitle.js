title = document.title.toUpperCase().bold();
document.write("MYCOOKING: ",title,"<br><hr>");